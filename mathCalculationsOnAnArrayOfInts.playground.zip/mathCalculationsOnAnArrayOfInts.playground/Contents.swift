/*
                                                                Grestest Possible Compunded Product of an Array
                                                                                Mark Sandomeno
 
                                        Sorts an array of random numbers and finds the greatest possible compunded product that the numbers can make

 
 Outline:
 
 1) Set-Up
 
    a. Append numbers entered by user to an array called 'array'
    b. Sort array in increasing order
    c. Establish MAX_VALUE, MIN_VALUE and print them out by using subscripts to find end indexs
    d. If-statement for whether to display MAX_VALUE / MIN_VALUE values based on user preference
 
 2) Execute
 
 a. Loop through the array as many times as elements it contains
 b. Establish a counter that is used as a subtraction value for the array index to move further and further away from the end; basically going backwards. A 'value' which will contain that end value as we loop, and finally the 'totaler' which will multiply and assign each value to it for the end product.
 c. Each value in the array as we move backwards.
 d. If-statement based on if user wants to see workings of loop
 f. Multiply and assign all values to 'totaler'
 g. Counter increments for next round of looping
 

 */


func greatestProductPossible(numbas: [Int], showWork: Bool) {
    
    //1a, b.
    var array = numbas
    array.sort()
    
    //1c.
    let MAX_NUM = array[array.count - 1]
    let MIN_NUM = array[0]
    
    //1d.
    if showWork == true {
        print(array)
        print("Max: \(MAX_NUM) Min: \(MIN_NUM)")
        
    }
 
    
    //2b.
    var counter = 1
    var value: Int = 0
    var totaler: Int = 1
    
    //2a.
    for i in 0...array.count - 1   {
        
    //2c.
        value = array[array.count - counter]
        
    //2d.
            if showWork == true {
            
                print("Iteration: \(counter): valueAtIndex: \(i) | Value: \(value)")
            
            }
        
    //2f, g.
        totaler = totaler * value
   
        counter += 1
       
    }
    
    print("Greatest Possible Product: \(totaler)")
    
    
}


greatestProductPossible(numbas: [8, 3, 2, 7], showWork: true)


/*
 
 Output:
 
 [2, 3, 7, 8]
 Max: 8 Min: 2
 Iteration: 1: valueAtIndex: 0 | Value: 8
 Iteration: 2: valueAtIndex: 1 | Value: 7
 Iteration: 3: valueAtIndex: 2 | Value: 3
 Iteration: 4: valueAtIndex: 3 | Value: 2
 Greatest Possible Product: 336


 
 */





